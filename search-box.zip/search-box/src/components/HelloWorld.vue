<template>
  <div>
    <h1>Simple Search Box Project</h1>
    <h2>Using Vue 3</h2>
    <input v-model="searchQuery" @input="search" placeholder="Search...">
    <ul>
      <li v-for="(result, index) in searchResults" :key="index">
        <div>
          <h3 v-html="highlightText(result.title)"></h3>
          <p v-html="highlightText(result.content)"></p>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      searchQuery: "",
      articles: [
        {
          title: "Vue 3 Guide",
          content: "A comprehensive guide to Vue 3 features and usage.",
        },
        {
          title: "Vue vs React",
          content: "Comparing Vue.js and React for front-end development.",
        },
        {
          title: "State Management",
          content: "Managing state with Vuex in Vue 3 applications.",
        },
      ],
      searchResults: [],
    };
  },
  methods: {
    search() {
      const query = this.searchQuery.toLowerCase();
      this.searchResults = this.articles.filter((article) =>
        article.title.toLowerCase().includes(query) ||
        article.content.toLowerCase().includes(query)
      );
    },
    highlightText(text) {
      const query = this.searchQuery.toLowerCase();
      const regex = new RegExp(query, "gi");
      return text.replace(regex, (match) => `<span class="highlight">${match}</span>`);
    },
  },
};
</script>

<style>
.highlight {
  background-color: yellow;
}
</style>
